<p align="center">
  <img width="480" src="https://github.com/diku-dk/DIKUArcade/blob/master/Logo/DIKU-Arcade.png?raw=true" alt="Material Bread logo">
</p>
<br>

Control the player by using the left/right arrow.<BR>
To use power ups, press the up arrow.<BR>
To pause game, press "P".<BR>
To enter main menu, press "M".<BR>
Press the ESC button to exit game.<BR>
The Game has an cheat function that spawns powerups when pressing the "Q-E-R-T-Y-U-I-O" keys.<BR>
Enjoy!
