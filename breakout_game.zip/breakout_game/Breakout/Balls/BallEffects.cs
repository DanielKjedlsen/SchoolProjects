using System.Collections.Generic;
using Breakout.PowerUps;
using DIKUArcade.Entities;
using DIKUArcade.Events;
using DIKUArcade.Math;

namespace Breakout.Balls {

    /// <summary>
    /// The power up effects that affects the balls.
    /// </summary>
    public class BallEffects : IPowerUpEffects {
        private GameEntityManager<Ball> balls;

        public BallEffects(GameEntityManager<Ball> balls) {
            this.balls = balls;
            var iterator = balls.GetIterator();
            BreakoutBus.GetBus().Subscribe(GameEventType.StatusEvent, this);
            BreakoutBus.GetBus().Subscribe(GameEventType.MovementEvent, this);
        }

        public void ResetEffects() {
            BreakoutBus.GetBus().CancelTimedEvent(666);
            BreakoutBus.GetBus().CancelTimedEvent(777);
            BreakoutBus.GetBus().CancelTimedEvent(888);
        }

        public void Split() {
            var newList = new List<Ball>();
            var iterator = balls.GetIterator();
            while(iterator.MoveNext()) {
                newList.Add(iterator.Current());
            }
            foreach(Ball ball in newList) {
                SplitBall(ball);
            }
        }

        public void SplitBall(Ball ball) {
            if (ball.GetDirection() != new Vec2F(0.0f, 0.0f)) {
                balls.Add(new Ball(new DynamicShape(ball.Shape.Position, ball.Shape.Extent, new Vec2F(ball.GetDirection().X, ball.GetDirection().Y)), ball.Image));
                balls.Add(new Ball(new DynamicShape(ball.Shape.Position, ball.Shape.Extent, new Vec2F(ball.GetDirection().Y, ball.GetDirection().X)), ball.Image));
                balls.Add(new Ball(new DynamicShape(ball.Shape.Position, ball.Shape.Extent, new Vec2F(-ball.GetDirection().Y, ball.GetDirection().X)), ball.Image));
                ball.DeleteEntity();
            }
        }

        public void DoubleSpeed() {
            var iterator = balls.GetIterator();
            while(iterator.MoveNext()) {
                iterator.Current().ChangeDirection(iterator.Current().GetDirection() * 2);
            }
        }

        public void HalfSpeed() {
            var iterator = balls.GetIterator();
            while(iterator.MoveNext()) {
                iterator.Current().ChangeDirection(iterator.Current().GetDirection() / 2);
            }
        }
        
        public void DoubleSize() {
            var iterator = balls.GetIterator();
            while(iterator.MoveNext()) {
                iterator.Current().Shape.Extent = Constants.DoubleBallExtent;
            }
        }
        public void NormalSize() {
            var iterator = balls.GetIterator();
            while(iterator.MoveNext()) {
                iterator.Current().Shape.Extent = Constants.BallExtent;
            }
        }

        public void ProcessEvent(GameEvent gameEvent) {
            switch (gameEvent.Message) {
                case "SPLIT":
                    Split();
                    break;
                case "DOUBLE_SPEED":
                    DoubleSpeed();
                    break;
                case "HALF_SPEED":
                    HalfSpeed();
                    break;
                case "DOUBLE_SIZE":
                    DoubleSize();
                    break;
                case "NORMAL_SIZE":
                    NormalSize();
                    break;
                default:
                    break;
            }
        }
    }
}