using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;
using DIKUArcade.Timers;

namespace Breakout.PowerUps {

    /// <summary>
    /// A visual representation of a power up that can double the size of the player.
    /// </summary>
    public class Wide : PowerUp {
        public Wide (DynamicShape shape, IBaseImage image) : base(shape, image) {}

        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, Message = "WIDE"});
            BreakoutBus.GetBus().RegisterTimedEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, Message = "NORMALIZE_SIZE"}, TimePeriod.NewSeconds(3.0));
        }
    }
}