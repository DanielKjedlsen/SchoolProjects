using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;
using DIKUArcade.Timers;

namespace Breakout.PowerUps {

    /// <summary>
    /// A visual representation of a power up that can make the player able to fire laser.
    /// </summary>
    public class FireLaser : PowerUp {
        public FireLaser (DynamicShape shape, IBaseImage image) : base (shape, image) {}

        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent {
                EventType = GameEventType.MovementEvent, Message = "FIRE_LASER"});
            BreakoutBus.GetBus().AddOrResetTimedEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, Id = 555, Message = "STOP_FIRING"}, TimePeriod.NewSeconds(5.0));
        }
    }
}