
namespace Breakout.PowerUps {
    public enum PowerUpType {
        
        DoubleSize,
        DoubleSpeed,
        ExtraLife,
        ExtraPoints,
        FireLaser,
        FireRocket,
        HalfSpeed,
        Split,
        Wide
    }
}