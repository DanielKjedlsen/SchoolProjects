using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;

namespace Breakout.PowerUps {

    /// <summary>
    /// A visual representation of a power up that can give the player extra points.
    /// </summary>
    public class ExtraPoints : PowerUp {
        public ExtraPoints (DynamicShape shape, IBaseImage image) : base(shape, image) {}

        
        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{ 
                EventType = GameEventType.MovementEvent, Message = "EXTRA_POINTS"});
        }
    }
}