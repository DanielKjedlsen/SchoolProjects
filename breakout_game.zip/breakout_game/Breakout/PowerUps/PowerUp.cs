using System;
using DIKUArcade;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace Breakout.PowerUps {

    /// <summary>
    /// An abstract class providing the basic funcionality of a power up.
    /// </summary>
    public abstract class PowerUp : Entity {
 
        public PowerUp(DynamicShape shape, IBaseImage image) : base(shape, image) {}

        public static DynamicShape DefinePowerUpShape(Vec2F position, Vec2F extent = null) {
            var powerUpExtent = extent ?? Constants.PowerUpExtent;
            return new DynamicShape(position, powerUpExtent, Constants.PowerUpDirection);
        }

        public Shape GetShape() {
            return Shape;
        }
        public Vec2F GetPosition() {
            return Shape.Position;
        }
        public void Move() {
            if (Shape.Position.Y < 0.0f - Shape.Extent.Y) {
                DeleteEntity();
            } else Shape.Move();
        }
        public abstract void ImposeEffect();
    }
}