using System;
using Breakout.LevelLoading;
using DIKUArcade.Events;
using DIKUArcade.Entities;
using DIKUArcade.Math;

namespace Breakout.PowerUps {

    /// <summary>
    /// A game entity manager for all power ups.
    /// </summary>
    public class PowerUpManager : GameEntityManager<PowerUp>, IGameEventProcessor {
        private PowerUpFactory powerUpFactory;
        private Random random;

        public PowerUpManager(LevelReader levelReader) {
            entities = new EntityContainer<PowerUp>();
            levelReader.Add(this);
            BreakoutBus.GetBus().Subscribe(GameEventType.MovementEvent, this);
            powerUpFactory = new PowerUpFactory();
            random = new Random();
        }

        public void SpawnPowerUp(Vec2F position) {
            var powerUpCount = Enum.GetNames(typeof(PowerUpType)).Length;
            var rd = random.Next(0, powerUpCount);
            PowerUp powerUp = powerUpFactory.CreatePowerUp(position, (PowerUpType)rd);
            Add(powerUp);
        }

        public override void Update() {
            entities.Iterate(powerUp => {
                powerUp.Move();
            });
        }

        public override void Render() {
            entities.RenderEntities();
        }

        public override void InstantiateNewLevel() {
            entities.ClearContainer();
        }

        /// <summary>
        /// Is used for spawning power ups at appropriate times and whenever the user requests it.
        /// </summary>
        public void ProcessEvent(GameEvent gameEvent) {
            if (gameEvent.Message == "ACTIVATE_POWERUP") {
                switch (gameEvent.StringArg1) {
                    case "DOUBLE_SIZE":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.1f, 0.6f), PowerUpType.DoubleSize));
                        break;
                    case "DOUBLE_SPEED":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.2f, 0.6f), PowerUpType.DoubleSpeed));
                        break;
                    case "EXTRA_LIFE":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.3f, 0.6f), PowerUpType.ExtraLife));
                        break;
                    case "EXTRA_POINTS":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.4f, 0.6f), PowerUpType.ExtraPoints));
                        break;
                    case "FIRE_LASER":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.5f, 0.6f), PowerUpType.FireLaser));
                        break;
                    case "FIRE_ROCKET":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.6f, 0.6f), PowerUpType.FireRocket));
                        break;
                    case "HALF_SPEED":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.7f, 0.6f), PowerUpType.HalfSpeed));
                        break;
                    case "SPLIT":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.8f, 0.6f), PowerUpType.Split));
                        break;
                    case "WIDE":
                        Add(powerUpFactory.CreatePowerUp(new Vec2F(0.9f, 0.6f), PowerUpType.Wide));
                        break;
                    default:
                        if (gameEvent.ObjectArg1 != null) {
                            var position = gameEvent.ObjectArg1 as Vec2F;
                            if (position != null)
                                SpawnPowerUp(position);
                        }    
                        break;
                }
                
            }
        }

    }
}