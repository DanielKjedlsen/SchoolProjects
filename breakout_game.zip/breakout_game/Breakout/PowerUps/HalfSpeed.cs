using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Timers;
using DIKUArcade.Events;


namespace Breakout.PowerUps{

    /// <summary>
    /// A visual representation of a power up that can half the speed of the ball.
    /// </summary>
    public class HalfSpeed : PowerUp {
        public HalfSpeed (DynamicShape shape, IBaseImage image) : base(shape, image) {}

        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{ 
                EventType = GameEventType.MovementEvent, Message = "HALF_SPEED"});
            BreakoutBus.GetBus().RegisterTimedEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, Id = 888, Message = "DOUBLE_SPEED"}, TimePeriod.NewSeconds(3.0));
            
        }
    }
}   