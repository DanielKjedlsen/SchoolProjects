using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;
using DIKUArcade.Timers;


namespace Breakout.PowerUps{

    /// <summary>
    /// A visual representation of a power up that can double the speed of the ball.
    /// </summary>
    public class DoubleSpeed : PowerUp {
        public DoubleSpeed (DynamicShape shape, IBaseImage image) : base(shape, image) {}

        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{ 
                EventType = GameEventType.MovementEvent, Message = "DOUBLE_SPEED"});
            BreakoutBus.GetBus().RegisterTimedEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, Id = 777, Message = "HALF_SPEED"}, TimePeriod.NewSeconds(3.0));
        }
    }
}   