using System.IO;
using DIKUArcade.Math;
using DIKUArcade.Graphics;

namespace Breakout.PowerUps {

    /// <summary>
    /// A factory responsible for the instantiation of power ups.
    /// </summary>
    public class PowerUpFactory {
        public PowerUpFactory() {}
        public PowerUp CreatePowerUp (Vec2F position, PowerUpType type) {
            PowerUp powerUp;
            switch (type) {
                case PowerUpType.Wide:
                    powerUp = new Wide(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "WidePowerUp.png")));
                    break;
                case PowerUpType.ExtraLife:
                    powerUp = new ExtraLife(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "LifePickUp.png")));
                    break;
                case PowerUpType.ExtraPoints:
                    powerUp = new ExtraPoints(PowerUp.DefinePowerUpShape(position, new Vec2F(0.05f, 0.02f)), new ImageStride(100, ImageStride.CreateStrides(6, Path.Combine("../", "Breakout", "Assets", "Images", "pointsStride.png"))));
                    break;
                case PowerUpType.Split:
                    powerUp = new Split(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "SplitPowerUp.png")));
                    break;
                case PowerUpType.HalfSpeed:
                    powerUp = new HalfSpeed(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "HalfSpeedPowerUp.png")));
                    break;
                case PowerUpType.DoubleSpeed:
                    powerUp = new DoubleSpeed(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "DoubleSpeedPowerUp.png")));
                    break;
                case PowerUpType.DoubleSize:
                    powerUp = new DoubleSize(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "BigPowerUp.png")));
                    break;
                case PowerUpType.FireLaser:
                    powerUp = new FireLaser(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "DamagePickUp.png")));
                    break;
                case PowerUpType.FireRocket:
                    powerUp = new FireRocket(PowerUp.DefinePowerUpShape(position), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "RocketPickUp.png")));
                    break;
                default:
                    powerUp =  null;
                    break;
            }
            return powerUp;
        }
    }
}