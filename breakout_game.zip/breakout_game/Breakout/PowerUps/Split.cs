using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;

namespace Breakout.PowerUps {

    /// <summary>
    /// A visual representation of a power up that can split one or more balls into three times as many.
    /// </summary>
    public class Split : PowerUp {
        public Split (DynamicShape shape, IBaseImage image) : base (shape, image) {}

        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent {
                EventType = GameEventType.StatusEvent, Message = "SPLIT"});
        }
    }
}