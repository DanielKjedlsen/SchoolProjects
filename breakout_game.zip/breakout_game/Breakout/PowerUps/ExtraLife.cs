using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;

namespace Breakout.PowerUps {

    /// <summary>
    /// A visual representation of a power up that can give the player an extra life.
    /// </summary>
    public class ExtraLife : PowerUp {
        public ExtraLife (DynamicShape shape, IBaseImage image) : base(shape, image) {}

        
        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{ 
                EventType = GameEventType.MovementEvent, Message = "EXTRA_LIFE"});
        }
    }
}