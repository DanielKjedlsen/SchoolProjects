using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;
using DIKUArcade.Timers;


namespace Breakout.PowerUps{

    /// <summary>
    /// A visual representation of a power up that can double the size of the ball.
    /// </summary>
    public class DoubleSize : PowerUp {
        public DoubleSize (DynamicShape shape, IBaseImage image) : base(shape, image) {}

        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{ 
                EventType = GameEventType.MovementEvent, Message = "DOUBLE_SIZE"});
            BreakoutBus.GetBus().RegisterTimedEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, Id = 666, Message = "NORMAL_SIZE"}, TimePeriod.NewSeconds(10.0));
        }
    }
}   