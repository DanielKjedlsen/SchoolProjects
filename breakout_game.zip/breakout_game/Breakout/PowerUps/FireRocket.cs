using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Events;

namespace Breakout.PowerUps {

    /// <summary>
    /// A visual representation of a power up that can make the player able to fire a rocket.
    /// </summary>
    public class FireRocket : PowerUp {
        public FireRocket (DynamicShape shape, IBaseImage image) : base (shape, image) {}

        public override void ImposeEffect() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent {
                EventType = GameEventType.MovementEvent, Message = "FIRE_ROCKET"});
            BreakoutBus.GetBus().CancelTimedEvent(555);
        }
    }
}