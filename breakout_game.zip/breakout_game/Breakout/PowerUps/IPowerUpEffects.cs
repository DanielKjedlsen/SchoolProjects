using DIKUArcade.Events;

namespace Breakout.PowerUps {

    /// <summary>
    /// An interface for classes implementing power up effects.
    /// </summary>
    public interface IPowerUpEffects : IGameEventProcessor {
        void ResetEffects();
    }
}