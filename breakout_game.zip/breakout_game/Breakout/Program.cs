﻿using DIKUArcade.GUI;

namespace Breakout {

    /// <summary>
    /// The program.
    /// </summary>
    class Program {
        static void Main(string[] args) {
            var windowArgs = new WindowArgs();
            var game = new Game(windowArgs);
            game.Run();
        }
    }
}