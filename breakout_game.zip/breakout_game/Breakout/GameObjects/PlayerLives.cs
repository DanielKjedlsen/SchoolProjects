using System.Collections.Generic;
using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.Math;
using DIKUArcade.Graphics;
using DIKUArcade.Events;


namespace Breakout.GameObjects {

    /// <summary>
    /// Adding or removing lives from the player. If lives are less than zero
    /// the game will end.
    /// </summary>
    public class PlayerLives : IGameObject, IGameEventProcessor {
        private int numOfLives;
        private readonly int maxNumOfLives = 5;
        private EntityContainer lives;
        private Dictionary<string, IBaseImage> imageDictionary;

        public PlayerLives() {
            BreakoutBus.GetBus().Subscribe(GameEventType.MovementEvent, this);
            BreakoutBus.GetBus().Subscribe(GameEventType.GameStateEvent, this);
            numOfLives = maxNumOfLives;
            imageDictionary = new Dictionary<string, IBaseImage>();
            imageDictionary.Add("heart_filled", new Image(Path.Combine("../", "Breakout", "Assets", "Images", "heart_filled.png")));
            imageDictionary.Add("heart_empty", new Image(Path.Combine("../", "Breakout", "Assets", "Images", "heart_empty.png")));
            lives = new EntityContainer(maxNumOfLives);
            for (int i = 1; i <= maxNumOfLives; i++) {
                lives.AddStationaryEntity(new StationaryShape(new Vec2F(0.22f - 0.04f * i, 0.94f), new Vec2F(0.04f, 0.04f)), imageDictionary["heart_filled"]);
            }
        }

        public void Update() {
            var i = 0;
            foreach(Entity life in lives) {
                if (i < numOfLives) {
                    life.Image = imageDictionary["heart_filled"];
                }
                else {
                    life.Image = imageDictionary["heart_empty"];
                }
                i++;
            }
        }

        public void Render() {
            lives.RenderEntities();
        }

        public int GetLives() {
            return numOfLives;
        }
        private void AddLife() {
            if (numOfLives < maxNumOfLives)
                numOfLives++;
        }

        private void RemoveLife() {
            numOfLives--;
            if (numOfLives < 0)
                SendGameOver();
        }

        private void ResetLives() {
            numOfLives = maxNumOfLives;
        }

        private void SendGameOver() {
            BreakoutBus.GetBus().RegisterEvent(new GameEvent {
                        EventType = GameEventType.GameStateEvent, Message = "GAME_OVER"});
        }

        public void ProcessEvent(GameEvent gameEvent) {
            if (gameEvent.Message == "LOSE_LIFE")
                RemoveLife();
            else if (gameEvent.Message == "EXTRA_LIFE")
                AddLife();
            else if (gameEvent.Message == "START_GAME")
                ResetLives();
        }
    }
}