
namespace Breakout.States {
    public enum GameStateType {
        MainMenu,
        GameRunning,
        GamePaused,
        GameOver,
        GameCompleted
    }
}

