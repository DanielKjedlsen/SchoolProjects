using System.IO;
using DIKUArcade.State;
using DIKUArcade.Input;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.Events;

namespace Breakout.States {

    /// <summary>
    /// A game state for when the game is lost.
    /// </summary>
    public class GameOver : IGameState {
        private Entity background;
        private Text text;
        public GameOver() {
            background = new Entity(Constants.BackGroundShape, 
                new Image(Path.Combine("../", "Breakout", "Assets", "Images", "shipit_titlescreen.png")));
            text = new Text("GAME OVER!", new Vec2F(0.2f, 0.1f), new Vec2F(0.6f, 0.6f));
            text.SetColor(new Vec3I(255, 255, 255));
        }
        
        public void ResetState() {}
        public void UpdateState() {}
        public void RenderState() {
            background.RenderEntity();
            text.RenderText();
        }
        public void HandleKeyEvent(KeyboardAction action, KeyboardKey key) {
            if (action == KeyboardAction.KeyPress) {
                if (key == KeyboardKey.M) {
                    StateMachine.GetStateMachine().SwitchGameState(GameStateType.MainMenu);
                } else if (key == KeyboardKey.Escape) {
                    BreakoutBus.GetBus().RegisterEvent(new GameEvent{
                        EventType = GameEventType.WindowEvent, Message = "CLOSE_WINDOW"});
                }
            }
        }
    }
}