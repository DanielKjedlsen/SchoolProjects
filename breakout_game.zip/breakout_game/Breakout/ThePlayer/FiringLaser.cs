using System.IO;
using Breakout.PlayerShots;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.Events;

namespace Breakout.ThePlayer {

    /// <summary>
    /// A behaviour that fires laser.
    /// </summary>
    public class FiringLaser : FiringBehaviour {
        public FiringLaser(Player player) {
            this.player = player;
            player.Image = new ImageStride(50, ImageStride.CreateStrides(3,Path.Combine("..", "Breakout" , "Assets", "Images", "playerStrideLaser.png")));
        }

        public override void Fire() {
            var leftLaser = Laser.GetNewLaser(player.Shape.Position);
            var rightLaser = Laser.GetNewLaser(new Vec2F(player.Shape.Position.X + player.Shape.Extent.X, player.Shape.Position.Y));
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, ObjectArg1 = leftLaser, Message = "FIRE"});
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, ObjectArg1 = rightLaser, Message = "FIRE"});
        }

        public override void Render() {
            player.RenderEntity();
        }


    }
}