using Breakout.PowerUps;
using DIKUArcade.Events;

namespace Breakout.ThePlayer {

    /// <summary>
    /// The power up effects that affects the player.
    /// </summary>
    public class PlayerEffects : IPowerUpEffects {

        private Player player;
        public PlayerEffects(Player player) {
            this.player = player;
            BreakoutBus.GetBus().Subscribe(GameEventType.MovementEvent, this);
        }

        public void FireRocket() {
            player.SetFiringBehaviour(new FiringRocket(player));
        }

        public void FireLaser() {
            player.SetFiringBehaviour(new FiringLaser(player));
        }

        public void FireNothing() {
            player.SetFiringBehaviour(new NoFiring(player));
        }

        public void Wide() {
            player.Shape.Extent = Constants.DoublePlayerExtent;
            player.Shape.Position.X -= Constants.PlayerExtent.X / 2;
            if (player.Shape.Position.X < 0.0f) {
                player.Shape.Position.X = 0.0f;
            } else if (player.Shape.Position.X + player.GetExtentX() > 1.0f) {
                player.Shape.Position.X = 1.0f - player.GetExtentX();
            }
        }

        public void NormalizeSize() {
            player.Shape.Extent = Constants.PlayerExtent;
            player.Shape.Position.X += Constants.PlayerExtent.X / 2;
        }
        public void ResetEffects() {
            NormalizeSize();
        }
        public void ProcessEvent(GameEvent gameEvent) {
                switch(gameEvent.Message) {
                    case "WIDE":
                        Wide();
                        break;
                    case "NORMALIZE_SIZE":
                        NormalizeSize();
                        break;
                    case "FIRE_ROCKET":
                        FireRocket();
                        break;
                    case "FIRE_LASER":
                        FireLaser();
                        break;
                    case "STOP_FIRING":
                        FireNothing();
                        break;
                    default:
                        break;
                }
        }
    }
}