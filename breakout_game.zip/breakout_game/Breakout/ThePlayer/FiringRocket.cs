using System.IO;
using Breakout.PlayerShots;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.Events;
using DIKUArcade.Entities;

namespace Breakout.ThePlayer {

    /// <summary>
    /// A behaviour that fires rockets.
    /// </summary>
    public class FiringRocket : FiringBehaviour {
        public static int numOfAvailableRockets = 0;
        private Entity playerRocket;
        public FiringRocket(Player player) {
            this.player = player;
            player.Image = new ImageStride(50, ImageStride.CreateStrides(3,Path.Combine("..", "Breakout" , "Assets", "Images", "playerStride.png")));
            numOfAvailableRockets++;
            playerRocket = new Entity(new DynamicShape(new Vec2F(0.0f, player.Shape.Position.Y - 0.01f), Constants.RocketExtent), new ImageStride(50, ImageStride.CreateStrides(5, Path.Combine("..", "Breakout" , "Assets", "Images", "Rocket.png"))));
        }

        public override void Fire() {
            var rocket = Rocket.GetNewRocket(new Vec2F(player.Shape.Position.X + player.Shape.Extent.X / 2, player.Shape.Position.Y));
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, ObjectArg1 = rocket, Message = "FIRE"});
            numOfAvailableRockets--;
            if (numOfAvailableRockets <= 0) {
                player.SetFiringBehaviour(new NoFiring(player));
            }
        }

        public override void Render() {
            playerRocket.Shape.Position.X = player.Shape.Position.X + player.Shape.Extent.X / 2 - Constants.RocketExtent.X / 2;
            player.RenderEntity();
            playerRocket.RenderEntity();
        }
    }
}