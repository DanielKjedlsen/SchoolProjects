using Breakout.LevelLoading;
using DIKUArcade.Entities;
using DIKUArcade.Events;

namespace Breakout.PlayerShots {

    /// <summary>
    /// A game entity manager for all player shots.
    /// </summary>
    public class PlayerShotManager : GameEntityManager<PlayerShot>, IGameEventProcessor {

        public PlayerShotManager(LevelReader levelReader) {
            levelReader.Add(this);
            BreakoutBus.GetBus().Subscribe(GameEventType.MovementEvent, this);
            entities = new EntityContainer<PlayerShot>();
        }

        public override void Update() {
            entities.Iterate(entity =>{
                entity.Move();
            });
        }

        public override void Render() {
            entities.RenderEntities();
        }

        public override void InstantiateNewLevel() {
            entities.ClearContainer();
        }

        public void ProcessEvent(GameEvent gameEvent) {
            if (gameEvent.Message == "FIRE") {
                if (gameEvent.ObjectArg1 != null) {
                    var playerShot = gameEvent.ObjectArg1 as PlayerShot;
                    if (playerShot != null)
                        Add(playerShot);
                }
            }   
        }
    }
}