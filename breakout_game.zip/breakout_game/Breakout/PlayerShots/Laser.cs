using System.IO;
using Breakout.Blocks;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace Breakout.PlayerShots {
    
    /// <summary>
    /// A fireable laser entity.
    /// </summary>
    public class Laser : PlayerShot {
        public Laser(DynamicShape shape, IBaseImage image) : base(shape, image) {
            damage = 3;
        }

        public static Laser GetNewLaser(Vec2F position) {
            return new Laser(new DynamicShape(position - Constants.LaserExtent / 2, Constants.LaserExtent, Constants.LaserDirection), new Image(Path.Combine("../", "Breakout", "Assets", "Images", "BulletRed2.png")));
        }

        public override void CollideWithBlock(Block block) {
            block.BlockHit(damage);
            DeleteEntity();
        }
    }
}