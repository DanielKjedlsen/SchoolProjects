using Breakout.Blocks;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;

namespace Breakout.PlayerShots {

    /// <summary>
    /// An abstract class providing the basic funcionality of a player shot.
    /// </summary>
    public abstract class PlayerShot : Entity {
        protected int damage;

        public PlayerShot(DynamicShape shape, IBaseImage image) : base(shape, image) {}

        public void Move() {
            if (Shape.Position.Y >= 1.0f) {
                DeleteEntity();
            } else Shape.Move();
        }

        public abstract void CollideWithBlock(Block block);
    }
}