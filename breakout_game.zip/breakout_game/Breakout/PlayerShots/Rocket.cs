using System.IO;
using Breakout.Blocks;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using DIKUArcade.Events;

namespace Breakout.PlayerShots {

    /// <summary>
    /// A fireable rocket entity.
    /// </summary>
    public class Rocket : PlayerShot {
        public Rocket(DynamicShape shape, IBaseImage image) : base(shape, image) {
            damage = 50;
        }

        public static Rocket GetNewRocket(Vec2F position) {
            return new Rocket(new DynamicShape(new Vec2F(position.X - Constants.RocketExtent.X / 2, position.Y), Constants.RocketExtent, Constants.RocketDirection), new ImageStride(50, ImageStride.CreateStrides(5, Path.Combine("..", "Breakout" , "Assets", "Images", "RocketLaunched.png"))));
        }

        public override void CollideWithBlock(Block block) {
            block.BlockHit(damage);
            var explosionPositionX = Shape.Position.X + Constants.RocketExtent.X / 2 - Constants.ExplosionExtent.X / 2;
            var explosionPositionY = Shape.Position.Y + Constants.RocketExtent.Y;
            var explosionPosition = new Vec2F(explosionPositionX, explosionPositionY);
            BreakoutBus.GetBus().RegisterEvent(new GameEvent{
                EventType = GameEventType.MovementEvent, ObjectArg1 = explosionPosition, Message = "EXPLOSION"});
            
            DeleteEntity();
        }
    }
}