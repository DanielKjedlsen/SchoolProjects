using Breakout.GameObjects;
using Breakout.Blocks;
using Breakout.ThePlayer;
using Breakout.PlayerShots;
using Breakout.PowerUps;
using Breakout.Balls;
using Breakout.Collisions;
using DIKUArcade.Graphics;

namespace Breakout.LevelLoading {

    /// <summary>
    /// A class responsible for holding all level components.
    /// </summary>
    public class LevelHolder {
        private LevelReader levelReader;

        public Player player;

        private ILevelChangeObserver levelSpecifics;
        private PlayerLives lives;

    
        private GameEntityManager<Block> blocks;
        private GameEntityManager<Ball> balls;
        private GameEntityManager<PowerUp> powerUps;
        private GameEntityManager<PlayerShot> playerShots;

        private AnimationContainer explosions;


        public LevelHolder() {
            levelReader = new LevelReader();


            player = new Player(Constants.PlayerShape);
            
            balls = new BallManager(levelReader);
            blocks = new BlockManager(levelReader);
            powerUps = new PowerUpManager(levelReader);
            playerShots = new PlayerShotManager(levelReader);

            levelSpecifics = new LevelSpecifics(levelReader);
            lives = new PlayerLives();

            explosions = new ExplosionContainer();
        }

        public void Update() {
            CollisionHandler.CheckAllCollision(blocks, balls, powerUps, playerShots, player);
            player.Update();

            levelSpecifics.Update();
            lives.Update();

            balls.Update();
            blocks.Update();
            powerUps.Update();
            playerShots.Update();
        }

        public void Render() {
            player.Render();

            lives.Render();

            balls.Render();
            blocks.Render();
            powerUps.Render();
            playerShots.Render();

            levelSpecifics.Render();

            explosions.RenderAnimations();
        }
    }
}