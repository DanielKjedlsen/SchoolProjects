using DIKUArcade.Math;
using DIKUArcade.Graphics;
using DIKUArcade.Timers;
using DIKUArcade.Events;

namespace Breakout.GameObjects {

    /// <summary>
    /// The time of the current level.
    /// </summary>
    public class LevelTimer : IMetaHandler, IGameEventProcessor {
        private int secondsOfTime;
        private Text timer;
        private GameTimer gameTimer;
        private static bool timerStarted;
        private bool includeTimer;
        public LevelTimer() {
            timer = new Text("", new Vec2F(0.44f, 0.67f), new Vec2F(0.2f, 0.3f));
            timer.SetColor(new Vec3F(1.0f, 1.0f, 1.0f));
            gameTimer = new GameTimer();
            includeTimer = false;
            BreakoutBus.GetBus().Subscribe(GameEventType.GameStateEvent, this);
        }

        public void HandleMeta(string[] meta) {
            timer.SetText("Unlimited time");
            includeTimer = false;
            for (int i = 0; i < meta.Length; i++) {
                if (meta[i].Split(" ")[0] == "Time:") {
                    var time = meta[i].Split(" ")[1];
                    secondsOfTime = GetIntTime(time);
                    timer.SetText("Time: " + secondsOfTime.ToString());
                    includeTimer = true;
                }
            }
        }

        private int GetIntTime(string timeString) {
            int time;
            try {
                 time = int.Parse(timeString);
            } catch {
                time = 300;
            }
            return time;
        }
        public void Update() {
            if (gameTimer.ShouldReset() && timerStarted && includeTimer) {
                secondsOfTime--;
                if (secondsOfTime < 0)
                    BreakoutBus.GetBus().RegisterEvent(new GameEvent {
                        EventType = GameEventType.GameStateEvent, Message = "GAME_OVER"});
                else timer.SetText("Time: " + secondsOfTime.ToString());
            }   
        }
        public void Render() {
            timer.RenderText();
        }

        public void ProcessEvent(GameEvent gameEvent) {
            if (gameEvent.Message == "START_LEVEL") {
                timerStarted = true;
            }
            else if (gameEvent.Message == "GAME_PAUSED") {
                timerStarted = false;
            }
            else if (gameEvent.Message == "GAME_UNPAUSED") {
                timerStarted = true;
            }
        }
    }
}